﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using com.calitha.goldparser;
namespace project
{
    public partial class Form1 : Form
    {
        MyParser project;
        public Form1()
        {
            InitializeComponent();
            project = new MyParser("project.cgt",listBox1,listBox2);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            project.Parse(textBox1.Text);
        
        }
    }
}
